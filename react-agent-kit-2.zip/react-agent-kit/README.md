# React Agent Kit
Copy contents into your project root.
**Claude Code:** `claude --agent orchestrator`, then e.g. "add-feature: user profile page" or "upgrade React 17 to 19".
**Copilot (VS Code):** pick the `orchestrator` agent, or run `/new-solution`, `/generate-docs`, `/add-feature`, `/upgrade`, `/migrate`.
Edit `CLAUDE.md` + `.github/copilot-instructions.md` stack defaults first.
Models (Claude): haiku = explore/docs, sonnet = orchestrate/build/review. Switch builder to opus for hard tasks.

## UI / design (Tailwind + shadcn/ui)
- `ui-designer` runs once per new project: Figma -> screenshots -> URL -> brand colors -> preset.
- Output: `agent-state/design-system.md` (builders must follow it) + theme + shadcn setup.
- Presets: `.claude/skills/ui-design/presets.md`. Polish checklist: `.claude/skills/ui-design/SKILL.md`.
- Optional: add Figma MCP (`claude mcp add --transport http figma https://mcp.figma.com/mcp`) and Playwright MCP for screenshot review.
- Model: ui-designer = sonnet.

## Visual checks (Playwright MCP)
- Configured in `.mcp.json` (Claude Code) and `.vscode/mcp.json` (Copilot). Headless, 1280x800, screenshots in `agent-state/screenshots/`.
- One-time: `npx playwright install chromium`. Claude Code asks you to approve the project MCP server on first use.
- `visual-reviewer` modes: `check` (vs design system), `baseline` (before upgrade/migrate), `parity` (after).
- Keep `agent-state/screens.md` to 5-10 screens; mark key ones. `agent-state/screenshots/` is git-ignored; remove that line if you want baselines committed.
- Optional: pin `@playwright/mcp` to a specific version instead of `@latest`.

## HTML prototype (optional) + handoffs
- Add `Prototype: <path>` to a `new-solution` prompt. Skip it and nothing changes.
- Flow: prototype-analyzer (haiku) -> prototype-map.md -> spec (conflicts listed) -> design-system from prototype -> build -> visual check vs prototype.
- Put page screenshots in `prototype/screenshots/` for more accurate visual checks.
- Handoffs: format in `agent-state/handoff-template.md`. You get a short Phase/Done/Produced/Decisions/Open questions/Next/Reply message at every approval and at the end.

Example:
/new-solution build from docs/requirements.md
Prototype: prototype/ (optional)
Stack: React 18, TS, Vite, Tailwind + shadcn
