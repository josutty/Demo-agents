# React UI Agent Kit – Project Rules
Run orchestrator mode: `claude --agent orchestrator`

## Token rules (all agents)
- Read `agent-state/repo-map.md` and `agent-state/conventions.md` first. Never re-scan the repo.
- Use Grep/Glob before Read. Read line ranges, not whole files.
- Subagents return <=400 tokens: summary + file paths. Never paste file contents back.
- Write long output to files in `agent-state/`, return only the path.
- Prefer codemods/CLI (jscodeshift, react-codemod, tsc, eslint --fix) over manual LLM edits.
- Stop and ask the human at each checkpoint marked [APPROVAL].

## Stack defaults (edit to match your project)
React + TypeScript, Vite, React Router, React Query, Tailwind CSS + shadcn/ui (Radix, lucide-react), Vitest + Testing Library, ESLint + Prettier.

## Handoffs
- Subagents end with format A; orchestrator messages the human with format B (see `agent-state/handoff-template.md`).
- Optional HTML prototype: `prototype-analyzer` -> `prototype-map.md`; requirement doc wins on behavior, prototype on visuals.

## Visual checks
- Playwright MCP is configured in `.mcp.json`. Only `visual-reviewer` uses it. Max 5 screens/run, key screens only.

## UI rules
- Read `agent-state/design-system.md` before any UI work. Use shadcn components + Tailwind tokens only.
- No inline styles or hard-coded colors/sizes. Support light/dark. Include loading/empty/error states.
- Existing projects: match the current look; never restyle unless asked.
