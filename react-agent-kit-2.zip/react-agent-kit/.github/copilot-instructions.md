# React UI project instructions
- Stack: React + TypeScript, Vite, React Router, Tailwind + shadcn/ui, Vitest + Testing Library.
- Read `agent-state/design-system.md` before UI work. shadcn components + Tailwind tokens only; no inline/hard-coded styles; light/dark; loading/empty/error states.
- Existing projects: match current look, never restyle unless asked.
- Read `agent-state/repo-map.md` and `agent-state/conventions.md` before exploring code.
- Follow existing patterns; reuse components; add tests; keep answers short.
- Prefer codemods/CLI over manual bulk edits.
- Handoffs: subagents end with format A; the orchestrator replies to the human with format B (`agent-state/handoff-template.md`).
- Optional HTML prototype: `agent-state/prototype-map.md` is the visual source; requirement doc wins on behavior.
- Save long outputs to `agent-state/` or `docs/`, reply with paths only.
