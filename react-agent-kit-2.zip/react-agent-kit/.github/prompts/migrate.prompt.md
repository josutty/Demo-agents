---
agent: orchestrator
description: Migrate a React project (e.g. CRA->Vite, JS->TS, class->hooks, Redux->RTK/Query, Router v5->v6+).
---
1. code-explorer: repo-map + inventory of files affected
2. migration-upgrade: plan.md with phased strategy (incremental, app stays buildable), codemods, rollback
3. [APPROVAL] human approves plan; create branch
3b. visual-reviewer `baseline` on key screens (before any change)
4. Execute phase by phase (migration-upgrade). Parallel builders only on independent folders.
5. Verify each phase: typecheck, lint, tests, build
6. [APPROVAL] before removing old tooling/code
7. visual-reviewer `parity` on key screens. reviewer on final diff; doc-generator updates docs
8. Final report
