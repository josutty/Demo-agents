---
agent: orchestrator
description: Add a new feature to an existing React product.
---
1. code-explorer if repo-map missing/stale
2. Write `agent-state/plan.md`: affected files, reuse candidates, tasks, test plan. If `design-system.md` is missing, ui-designer records existing styles first (no redesign) (orchestrator from repo-map, no source reads)
3. [APPROVAL] human approves plan
4. builder per task
5. reviewer on diff; visual-reviewer `check` on changed screens only; builder fixes; max 2 review loops
6. doc-generator: update only affected docs
7. Final report
