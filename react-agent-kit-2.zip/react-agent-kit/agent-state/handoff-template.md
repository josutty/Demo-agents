# Handoff formats

## A. Subagent -> orchestrator (end of every subagent reply, max 80 words)
STATUS: done | blocked | needs-input
OUT: <file paths>
DECIDED: <key decisions/assumptions, 1 line each>
BLOCKERS: <none | list>
NEXT: <suggested next step>

## B. Orchestrator -> human (at every [APPROVAL] checkpoint and at the end, max 150 words)
**Phase:** <name> - <complete | blocked | needs input>
**Done:** <what finished>
**Produced:** <file paths>
**Decisions/assumptions:** <what agents chose>
**Open questions:** <numbered; "none" if none>
**Next:** <next phase> by <agent>
**Reply:** "approved" or tell me what to change

Final message (end of workflow) uses the same fields, with Next = follow-ups, and adds **Verify:** typecheck/lint/test/build results.
