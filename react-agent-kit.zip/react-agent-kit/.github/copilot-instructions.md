# React UI project instructions
- Stack: React + TypeScript, Vite, React Router, Vitest + Testing Library.
- Read `agent-state/repo-map.md` and `agent-state/conventions.md` before exploring code.
- Follow existing patterns; reuse components; add tests; keep answers short.
- Prefer codemods/CLI over manual bulk edits.
- Save long outputs to `agent-state/` or `docs/`, reply with paths only.
