---
name: new-solution
description: Build a new React app from a requirement document.
---
1. requirements-analyst -> `agent-state/spec.md`
2. [APPROVAL] human reviews spec and assumptions
3. builder: scaffold (Vite+TS, routing, lint, test, folder layout) -> write `conventions.md`
4. [APPROVAL] human confirms scaffold
5. builder: one backlog task at a time (shared components first, then screens). Run tasks in parallel only when independent.
6. reviewer after every 3-5 tasks
7. doc-generator: README + component docs
8. Final report
