---
name: upgrade
description: Upgrade dependencies or framework versions in an existing React project.
---
1. code-explorer if repo-map missing/stale
2. migration-upgrade: plan.md (changelog/breaking-change analysis, codemods, order)
3. [APPROVAL] human approves plan; create git branch
4. migration-upgrade executes step by step with verify after each
5. reviewer on final diff
6. Final report: changes, deprecations remaining, follow-ups
