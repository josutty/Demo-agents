# React Agent Kit
Copy contents into your project root.
**Claude Code:** `claude --agent orchestrator`, then e.g. "add-feature: user profile page" or "upgrade React 17 to 19".
**Copilot (VS Code):** pick the `orchestrator` agent, or run `/new-solution`, `/generate-docs`, `/add-feature`, `/upgrade`, `/migrate`.
Edit `CLAUDE.md` + `.github/copilot-instructions.md` stack defaults first.
Models (Claude): haiku = explore/docs, sonnet = orchestrate/build/review. Switch builder to opus for hard tasks.
