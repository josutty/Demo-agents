---
agent: orchestrator
description: Add a new feature to an existing React product, optionally from an HTML prototype or mockup.
---
Inputs: feature description (required); HTML prototype/mockup path for the feature (optional); API spec, reuse hints, acceptance criteria (optional).
Rule: the existing `design-system.md` wins on tokens (colors, fonts, spacing). The prototype only defines layout, content and behavior of the new feature. Never restyle the existing app.

1. code-explorer if `agent-state/repo-map.md` is missing/stale
1b. If `design-system.md` is missing, ui-designer records existing styles (no redesign)
1c. If prototype given: prototype-analyzer (only the pages for this feature) -> `prototype-map.md`, mapped to existing tokens/components
2. Write `agent-state/plan.md` (orchestrator, from repo-map; no source reads): affected files, reuse candidates, tasks, test plan, and when a prototype exists a page -> route -> components map plus any new tokens needed
3. [APPROVAL] handoff (format B): plan, assumptions, prototype mismatches
4. builder per task
5. reviewer on diff; visual-reviewer `check` on changed screens only (vs prototype if present); builder fixes; max 2 loops
6. doc-generator: update only affected docs
7. Final handoff (format B + Verify)
