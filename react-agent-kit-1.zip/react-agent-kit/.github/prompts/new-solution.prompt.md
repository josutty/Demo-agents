---
agent: orchestrator
description: Build a new React app from a requirement document.
---
1. requirements-analyst -> `agent-state/spec.md`
2. [APPROVAL] human reviews spec and assumptions
3. Design intake: ask once "Figma link, screenshots, reference site, or brand colors? (else I'll propose presets)". Then ui-designer -> `design-system.md` + theme + shadcn init
4. [APPROVAL] human approves style (show palette, type, layout summary)
5. builder: scaffold (Vite+TS, Tailwind+shadcn, routing, lint, test, layout shell) -> write `conventions.md`
6. [APPROVAL] human confirms scaffold
7. builder: one backlog task at a time (shared components first, then screens). Parallel only when independent.
8. reviewer after every 3-5 tasks (includes design-system check)
8b. Maintain `agent-state/screens.md` (routes, key screens). visual-reviewer `check` after each completed screen group; builder fixes; max 2 loops
9. doc-generator: README + component docs
10. Final report
