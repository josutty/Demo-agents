Place your OpenAPI/Swagger YAML here as `api/openapi.yaml`.
Agents generate the client, hooks and mocks from it (skill: api-client). Never edit `src/api/generated/`.
