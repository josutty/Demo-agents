---
agent: orchestrator
description: Upgrade dependencies or framework versions in an existing React project.
---
1. code-explorer if repo-map missing/stale
2. migration-upgrade: plan.md (changelog/breaking-change analysis, codemods, order)
3. [APPROVAL] handoff (format B): current vs target, breaking changes, steps, risks, rollback point; then create git branch
3b. visual-reviewer `baseline` on key screens (before any change)
4. migration-upgrade executes step by step with verify after each
5. visual-reviewer `parity` on key screens. reviewer on final diff
6. Final handoff (format B + Verify): changes, deprecations remaining, follow-ups
