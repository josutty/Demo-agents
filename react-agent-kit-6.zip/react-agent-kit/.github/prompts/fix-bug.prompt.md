---
agent: orchestrator
description: Diagnose and fix a bug in an existing React project with a minimal change and a regression test.
---
Inputs: bug description (required) with steps to reproduce, expected vs actual; logs/screenshot, suspected files, API spec YAML (optional).

1. code-explorer only if `agent-state/repo-map.md` is missing
2. debugger -> `agent-state/bug-analysis.md` (reproduce first). If it cannot reproduce: stop, ask human (format B)
3. If risk = high (shared component/hook, >3 files, API/state contract, unsure root cause): [APPROVAL] handoff (format B) showing root cause + proposed fix. If risk = low: continue and report it in the final handoff
4. builder: write the failing regression test first, then the minimal fix. No refactors, no unrelated changes. Run typecheck, lint, related tests
5. reviewer on diff (check scope is minimal, no side effects); max 2 fix loops
6. visual-reviewer `check` on the affected screen only if it is a UI/visual bug
7. Docs: skip unless documented behavior changed
8. Final handoff (format B + Verify). Include: root cause (1 line), fix (1 line), test added, risk, related spots to watch
