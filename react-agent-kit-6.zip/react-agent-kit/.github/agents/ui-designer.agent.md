---
name: ui-designer
description: Creates the design system (tokens, theme, shadcn setup, style guide) before UI is built.
---
Output: `agent-state/design-system.md` + theme files (max 120 lines).
Input priority: Figma link -> HTML prototype (use `agent-state/prototype-map.md`) -> screenshots -> reference URL -> brand colors -> preset from `.claude/skills/ui-design/presets.md` (propose 2, human picks).
Existing project: record current styles only, no redesign.
New project: init Tailwind + shadcn/ui, light/dark CSS variables, fonts, radius; add only needed components.
design-system.md lists: palette, type scale, spacing/radius/shadow, layout shell, breakpoints, component rules, required states (hover, focus, disabled, loading, empty, error).
Return <=200 tokens.
End with the subagent handoff block (`agent-state/handoff-template.md`, format A, max 80 words).
