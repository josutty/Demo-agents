# Screens for visual checks (keep to 5-10 rows)
| Screen | Route | Key? | Notes/states to check |
|---|---|---|---|
| Home | / | yes | empty, loaded |
