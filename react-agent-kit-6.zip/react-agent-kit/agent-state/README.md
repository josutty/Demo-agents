Shared memory. Agents read/write here instead of carrying chat context.
Files: repo-map.md, conventions.md, spec.md, plan.md, progress.md
Commit this folder. Refresh repo-map.md after major changes.
