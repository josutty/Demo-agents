import { defineConfig } from 'orval';
import { existsSync } from 'node:fs';

const project = (input: string, dir: string) => ({
  input,
  output: {
    mode: 'tags-split' as const,
    target: dir,
    schemas: `${dir}/model`,
    client: 'react-query' as const,
    mock: true, // MSW handlers (*.msw.ts) using faker
    override: { mutator: { path: 'src/api/http.ts', name: 'http' } },
  },
});

export default defineConfig({
  // Real, backend-confirmed contract
  api: project('./api/openapi.yaml', 'src/api/generated'),
  // Optional: agent-drafted endpoints missing from the real spec (generated only if the file exists)
  ...(existsSync('./api/openapi.proposed.yaml')
    ? { proposed: project('./api/openapi.proposed.yaml', 'src/api/generated-proposed') }
    : {}),
});
