import { setupWorker } from 'msw/browser';

type Factory = () => unknown[];

// Orval-generated handler factories: real spec + proposed spec (*.msw.ts exporting get<Tag>Mock)
const generated = import.meta.glob('../api/generated*/**/*.msw.ts', { eager: true }) as Record<
  string,
  Record<string, unknown>
>;

// Hand-written mocks for small gaps: src/mocks/manual/*.ts exporting `handlers`
const manual = import.meta.glob('./manual/*.ts', { eager: true }) as Record<
  string,
  { handlers?: unknown[] }
>;

const generatedHandlers = Object.values(generated).flatMap((mod) =>
  Object.entries(mod)
    .filter(([name, fn]) => /^get.*Mock$/.test(name) && typeof fn === 'function')
    .flatMap(([, fn]) => (fn as Factory)()),
);
const manualHandlers = Object.values(manual).flatMap((m) => m.handlers ?? []);

export const worker = setupWorker(
  ...([...manualHandlers, ...generatedHandlers] as Parameters<typeof setupWorker>),
);

export async function enableMocks() {
  if (import.meta.env.VITE_USE_MOCKS === 'true') {
    await worker.start({ onUnhandledRequest: 'bypass' });
  }
}
// Run `npx msw init public/` once to create the service worker file.
