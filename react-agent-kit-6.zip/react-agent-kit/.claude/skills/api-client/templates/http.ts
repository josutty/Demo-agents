import Axios, { AxiosRequestConfig } from 'axios';

const instance = Axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? '',
});

// Add auth headers / interceptors here.
export const http = <T>(config: AxiosRequestConfig, options?: AxiosRequestConfig): Promise<T> =>
  instance({ ...config, ...options }).then(({ data }) => data as T);

export default http;
