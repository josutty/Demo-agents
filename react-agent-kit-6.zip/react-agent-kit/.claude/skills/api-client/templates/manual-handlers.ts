// Copy to src/mocks/manual/<feature>.ts. Use ONLY for small API gaps (option C).
import { http, HttpResponse } from 'msw';
// import type { Foo } from '../../api/generated/model'; // type responses from generated models when possible

export const handlers = [
  // GAP: GET /api/example (screen: Dashboard) - replace when backend confirms
  http.get('*/api/example', () => HttpResponse.json({ items: [] })),
];
