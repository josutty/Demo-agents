---
name: api-client
description: Generate a typed API client, React Query hooks and MSW mocks from an OpenAPI YAML spec, and handle partial specs (real / proposed / manual-mock endpoints). Use when an API spec is provided or changed.
---
Never hand-write API calls or edit `src/api/generated*/`. Always regenerate.

## Setup (once)
1. Validate: `npx @redocly/cli lint api/openapi.yaml`. Fix nothing in the spec yourself; report errors. If `paths` is missing or `$ref`s are broken: stop and ask (format B).
2. Install: `npm i axios @tanstack/react-query` and `npm i -D orval msw @faker-js/faker`.
3. Copy templates (skip existing): `templates/orval.config.ts` -> `orval.config.ts`; `templates/http.ts` -> `src/api/http.ts`; `templates/browser.ts` -> `src/mocks/browser.ts`.
4. package.json scripts: `"api:generate": "orval"`, optional `"api:mock": "npx @stoplight/prism-cli mock api/openapi.yaml"`.
5. `npm run api:generate`.
6. Wire: QueryClientProvider at root; `enableMocks()` before render in `main.tsx` (on only when `VITE_USE_MOCKS=true`); `VITE_API_BASE_URL` in `.env`.
7. Add `src/api/generated*` to eslint/prettier ignore. Typecheck.
8. Record in `agent-state/conventions.md`: spec paths, generate command, env vars, mock toggle.

## Partial specs (gaps)
Gap = an endpoint a screen/requirement needs that is missing from `api/openapi.yaml`, or a response with no schema.
1. requirements-analyst lists gaps in `agent-state/api-gaps.md`:
   | Endpoint | Needed by (screen) | Status (real / proposed / manual-mock) | Confirmed by backend? |
2. In the approval handoff, show the gaps and offer per gap (default B for large gaps, C for tiny ones):
   - A. Human adds it to `openapi.yaml` (then re-run generation).
   - B. Agent drafts it in `api/openapi.proposed.yaml` (never edit `openapi.yaml`).
   - C. Hand-written MSW mock in `src/mocks/manual/` (small gaps only).
3. Option B drafting rules (`templates/openapi.proposed.example.yaml`):
   - Header comment `PROPOSED - not confirmed`; `x-proposed: true` + reason on every operation.
   - Follow the real spec's conventions (naming, pagination, error shape, auth). Reuse its schemas with `$ref: './openapi.yaml#/components/schemas/X'`.
   - Minimal: only fields the screens use. Include `example` values so mocks look realistic.
   - Do not invent unknown field names for responses with no schema: ask the human.
4. Generated proposed code lives in `src/api/generated-proposed/`, so imports from it are easy to grep and swap.
5. Update `api-gaps.md` statuses; the final handoff reports counts: real / proposed / manual.

## When the backend confirms an endpoint
Move it from `openapi.proposed.yaml` into `openapi.yaml`, regenerate, replace imports `generated-proposed` -> `generated` (grep + sed), delete it from the proposed file (delete the file when empty), typecheck/tests, update `api-gaps.md`.

## When the YAML changes
Re-run `npm run api:generate`, typecheck, fix only broken call sites, report breaking contract changes.

## Rules
- Components use generated hooks only; no raw fetch/axios in components.
- Orval options change between versions: check the installed version's docs if generation fails.
