---
name: new-solution
description: Build a new React app from a requirement document, optionally with an HTML prototype.
---
Inputs: requirement doc (required); API spec YAML path (optional); HTML prototype path (optional); Figma/screenshots/brand (optional).
Requirement doc wins on behavior/data; prototype wins on visuals. Conflicts go to spec.md, never guessed.

1. If prototype given: prototype-analyzer -> `agent-state/prototype-map.md`
2. requirements-analyst -> `agent-state/spec.md` (include screen map: page -> route -> components, and a "Conflicts/gaps" section when a prototype exists)
3. [APPROVAL] handoff message (format B): spec, screen map, conflicts/assumptions, and API gaps with options A/B/C per gap (see `api-client` skill)
4. Design: ui-designer -> `design-system.md` + theme + shadcn init. Source priority: Figma > prototype > screenshots > URL > brand > presets. If no design input and no prototype, ask once ("Figma, screenshots, reference site or brand colors? else I propose presets")
5. [APPROVAL] handoff message: style summary (palette, type, layout)
6. builder: scaffold (Vite+TS, Tailwind+shadcn, routing, lint, test, layout shell) -> `conventions.md`
6b. If API spec given: builder applies `api-client` skill (generate client, hooks, mocks; mocks on via VITE_USE_MOCKS), plus `openapi.proposed.yaml` / manual mocks for the gaps you chose
   If no API spec: builder creates a typed API layer with MSW mocks
7. [APPROVAL] handoff message: scaffold
8. builder: one backlog task at a time (shared components first, then screens). Parallel only when independent.
9. reviewer after every 3-5 tasks (includes design-system check)
9b. Maintain `agent-state/screens.md`. visual-reviewer `check` after each completed screen group (vs prototype if present); builder fixes; max 2 loops
10. doc-generator: README + component docs
11. Final handoff message (format B + Verify)
