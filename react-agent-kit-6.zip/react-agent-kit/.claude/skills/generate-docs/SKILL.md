---
name: generate-docs
description: Generate documentation from existing React code.
---
1. code-explorer if repo-map is missing/stale
2. Split repo into modules from repo-map
3. doc-generator per module (parallel, small scope)
4. doc-generator: assemble architecture.md + README + index
5. reviewer: spot-check accuracy (sample only)
6. Final handoff (format B): docs produced, doc gaps (TODOs), Verify = spot-check result
