---
name: ui-design
description: UI polish checklist and design presets for Tailwind + shadcn/ui. Load when building or reviewing UI.
---
## Polish checklist (apply to every screen)
- Use design tokens/classes only. No hard-coded hex, px or inline styles.
- Compose shadcn components (Button, Card, Dialog, Table, Form...). Don't hand-roll equivalents.
- Consistent spacing scale (Tailwind 4/6/8), one container max-width, aligned grids.
- Clear type hierarchy: one h1, muted secondary text, max 2 font weights per view.
- Every data view has loading (Skeleton), empty, and error states.
- Interactive: hover, focus-visible ring, disabled; keyboard reachable; labels on inputs.
- Contrast >= WCAG AA; works in light and dark.
- Responsive: mobile-first; sidebar collapses; tables scroll or become cards.
- Icons: lucide-react, one size per context. Subtle motion only (150-200ms).
- Use sonner/toast for feedback, never alert().

Presets: see `presets.md` in this folder.
