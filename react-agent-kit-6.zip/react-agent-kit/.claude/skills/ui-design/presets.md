# Presets (pick one; override with brand colors if given)
All use Tailwind + shadcn/ui, Lucide icons, CSS variables (light + dark).

## 1. Minimal (SaaS, internal tools)
shadcn "neutral" base, accent indigo (#4F46E5), Inter, radius 0.5rem, soft borders, almost no shadow, generous whitespace, sidebar + top bar.

## 2. Corporate (enterprise, finance, admin)
Base slate, accent blue (#1D4ED8), Inter/IBM Plex Sans, radius 0.375rem, dense tables, breadcrumbs, left nav with sections, subtle card shadows.

## 3. Modern Dark (dev tools, analytics)
Dark default, zinc base, accent violet or emerald, Geist/Inter + mono for data, radius 0.75rem, thin borders, glass/blur on overlays sparingly, command palette (cmdk).

## 4. Friendly (consumer, onboarding, education)
Light, warm neutral base, accent orange or teal, rounded font (Nunito/Plus Jakarta Sans), radius 1rem, larger type, illustrations/empty states, pill buttons.
