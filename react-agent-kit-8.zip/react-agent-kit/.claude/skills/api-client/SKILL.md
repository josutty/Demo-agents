---
name: api-client
description: Generate a typed API client and React Query hooks from an OpenAPI YAML spec. Endpoints in the spec call the real API; only gap endpoints are mocked. Handles partial specs (real / proposed / manual-mock endpoints). Use when an API spec is provided or changed.
---
Never hand-write API calls or edit `src/api/generated*/`. Always regenerate.

## Setup (once)
1. Validate: `npx @redocly/cli lint api/openapi.yaml`. Fix nothing in the spec yourself; report errors. If `paths` is missing or `$ref`s are broken: stop and ask (format B).
2. Install: `npm i axios @tanstack/react-query` and `npm i -D orval msw @faker-js/faker`.
3. Copy templates (skip existing): `templates/orval.config.ts` -> `orval.config.ts`; `templates/http.ts` -> `src/api/http.ts`; `templates/browser.ts` -> `src/mocks/browser.ts`.
4. package.json scripts: `"api:generate": "orval"`, optional `"api:mock": "npx @stoplight/prism-cli mock api/openapi.yaml"`.
5. `npm run api:generate`.
6. Wire: QueryClientProvider at root; `enableMocks()` before render in `main.tsx`; copy `.env.example` to `.env` and set `VITE_API_BASE_URL`. Optional: Vite dev proxy to avoid CORS (`server.proxy: { '/api': { target: <backend>, changeOrigin: true } }` in vite.config.ts, then leave `VITE_API_BASE_URL` empty).
7. Add `src/api/generated*` to eslint/prettier ignore. Typecheck.
8. Record in `agent-state/conventions.md`: spec paths, generate command, env vars, mock toggle.

## Hybrid mode: real where possible, mock only the gaps
- Endpoint in `openapi.yaml` -> generated hook calls the REAL API and returns real data. No mock is generated for it.
- Endpoint in `openapi.proposed.yaml` or `src/mocks/manual/` -> MSW intercepts it and returns mock data. Anything MSW does not match passes through to the real API.
- Smoke test after generation (if `VITE_API_BASE_URL` is set): call one or two real GET endpoints with curl. Report 404/401/CORS/timeouts in the handoff instead of silently falling back to mocks. Never mock a real-spec endpoint to hide a backend problem.
- Auth: put token/headers logic in `src/api/http.ts`; ask the human how auth works if the spec defines securitySchemes.
- Real responses can differ from the spec: when typecheck passes but data looks wrong, report the mismatch; do not patch around it.
- Handoff API line: `real (live) N / mocked (proposed+manual) M` + smoke-test result. Mocked endpoints mean the app is not production-ready until the backend adds them.

## Partial specs (gaps)
Gap = an endpoint a screen/requirement needs that is missing from `api/openapi.yaml`, or a response with no schema.
1. requirements-analyst lists gaps in `agent-state/api-gaps.md`:
   | Endpoint | Needed by (screen) | Status (real = live / proposed = mocked / manual = mocked) | Confirmed by backend? |
2. In the approval handoff, show the gaps and offer per gap (default B for large gaps, C for tiny ones):
   - A. Human adds it to `openapi.yaml` (then re-run generation).
   - B. Agent drafts it in `api/openapi.proposed.yaml` (never edit `openapi.yaml`).
   - C. Hand-written MSW mock in `src/mocks/manual/` (small gaps only).
3. Option B drafting rules (`templates/openapi.proposed.example.yaml`):
   - Header comment `PROPOSED - not confirmed`; `x-proposed: true` + reason on every operation.
   - Follow the real spec's conventions (naming, pagination, error shape, auth). Reuse its schemas with `$ref: './openapi.yaml#/components/schemas/X'`.
   - Minimal: only fields the screens use. Include `example` values so mocks look realistic.
   - Do not invent unknown field names for responses with no schema: ask the human.
4. Generated proposed code lives in `src/api/generated-proposed/`, so imports from it are easy to grep and swap.
5. Update `api-gaps.md` statuses; the final handoff reports counts: real / proposed / manual.

## When the backend confirms an endpoint
Move it from `openapi.proposed.yaml` into `openapi.yaml`, regenerate (its mock disappears automatically and the hook now calls the real API), replace imports `generated-proposed` -> `generated` (grep + sed), delete it from the proposed file (delete the file when empty), typecheck/tests, update `api-gaps.md`.

## When the YAML changes
Re-run `npm run api:generate`, typecheck, fix only broken call sites, report breaking contract changes.

## Rules
- Components use generated hooks only; no raw fetch/axios in components.
- Orval options change between versions: check the installed version's docs if generation fails.
