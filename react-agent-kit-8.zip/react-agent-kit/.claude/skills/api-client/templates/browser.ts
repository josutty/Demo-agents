import { setupWorker } from 'msw/browser';

type Factory = () => unknown[];

// GAP endpoints only: Orval handlers from the proposed spec + hand-written mocks.
// Endpoints in the real spec have no handler, so they pass through to the real API.
const proposed = import.meta.glob('../api/generated-proposed/**/*.msw.ts', { eager: true }) as Record<
  string,
  Record<string, unknown>
>;
const manual = import.meta.glob('./manual/*.ts', { eager: true }) as Record<
  string,
  { handlers?: unknown[] }
>;

const proposedHandlers = Object.values(proposed).flatMap((mod) =>
  Object.entries(mod)
    .filter(([name, fn]) => /^get.*Mock$/.test(name) && typeof fn === 'function')
    .flatMap(([, fn]) => (fn as Factory)()),
);
const manualHandlers = Object.values(manual).flatMap((m) => m.handlers ?? []);
const handlers = [...manualHandlers, ...proposedHandlers];

export const worker = setupWorker(...(handlers as Parameters<typeof setupWorker>));

export async function enableMocks() {
  // Default ON; set VITE_MOCK_GAPS=false once the backend has every endpoint.
  if (import.meta.env.VITE_MOCK_GAPS === 'false' || handlers.length === 0) return;
  await worker.start({ onUnhandledRequest: 'bypass' }); // unmatched requests go to the real API
  console.info(
    '[mocks] mocked gap endpoints:',
    handlers.map((h) => (h as { info?: { header?: string } }).info?.header),
  );
}
// Run `npx msw init public/` once to create the service worker file.
