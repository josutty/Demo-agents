import { defineConfig } from 'orval';
import { existsSync } from 'node:fs';

const project = (input: string, dir: string, mock: boolean) => ({
  input,
  output: {
    mode: 'tags-split' as const,
    target: dir,
    schemas: `${dir}/model`,
    client: 'react-query' as const,
    mock, // MSW handlers (*.msw.ts) using faker, only where true
    override: { mutator: { path: 'src/api/http.ts', name: 'http' } },
  },
});

export default defineConfig({
  // Backend-confirmed contract: calls the REAL API, no mocks generated
  api: project('./api/openapi.yaml', 'src/api/generated', false),
  // Agent-drafted endpoints missing from the real spec: MOCKED (generated only if the file exists)
  ...(existsSync('./api/openapi.proposed.yaml')
    ? { proposed: project('./api/openapi.proposed.yaml', 'src/api/generated-proposed', true) }
    : {}),
});
