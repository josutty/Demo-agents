# Handoff formats

## A. Subagent -> orchestrator (end of every subagent reply, max 80 words)
STATUS: done | blocked | needs-input
OUT: <file paths>
DECIDED: <key decisions/assumptions, 1 line each>
BLOCKERS: <none | list>
NEXT: <next step> -> agent: <exact agent name, e.g. builder>

## B. Orchestrator -> human (at every [APPROVAL] checkpoint and at the end, max 150 words)
**Phase:** <name> - <complete | blocked | needs input>
**Done:** <what finished>
**Produced:** <file paths>
**Decisions/assumptions:** <what agents chose>
**API:** <only if an API spec/gaps exist: real (live) vs mocked (proposed + manual) endpoint counts, backend smoke-test result, decisions needed>
**Open questions:** <numbered; "none" if none>
**Next:** <next phase> -> **agent: <exact agent name(s)>** (e.g. `ui-designer`; list every agent if several run, in order; if a human action is needed first, say "you: <action>, then agent: <name>"; at the end: "none, workflow complete")
**Reply:** "approved" or tell me what to change

Final message (end of workflow) uses the same fields, with Next = follow-ups, and adds **Verify:** typecheck/lint/test/build results; if any could not run (e.g. no terminal), write "UNVERIFIED: <which>" plus the exact commands for the human to run. Never report unverified checks as passed.
