# React Agent Kit
Copy contents into your project root.
**Claude Code:** `claude --agent orchestrator`, then e.g. "add-feature: user profile page" or "upgrade React 17 to 19".
**Copilot (VS Code):** pick the `orchestrator` agent, or run `/new-solution`, `/generate-docs`, `/add-feature`, `/upgrade`, `/migrate`.
Edit `CLAUDE.md` + `.github/copilot-instructions.md` stack defaults first.
Models (Claude): haiku = explore/docs, sonnet = orchestrate/build/review. Switch builder to opus for hard tasks.

## UI / design (Tailwind + shadcn/ui)
- `ui-designer` runs once per new project: Figma -> screenshots -> URL -> brand colors -> preset.
- Output: `agent-state/design-system.md` (builders must follow it) + theme + shadcn setup.
- Presets: `.claude/skills/ui-design/presets.md`. Polish checklist: `.claude/skills/ui-design/SKILL.md`.
- Optional: add Figma MCP (`claude mcp add --transport http figma https://mcp.figma.com/mcp`) and Playwright MCP for screenshot review.
- Model: ui-designer = sonnet.

## Visual checks (Playwright MCP)
- Configured in `.mcp.json` (Claude Code) and `.vscode/mcp.json` (Copilot). Headless, 1280x800, screenshots in `agent-state/screenshots/`.
- One-time: `npx playwright install chromium`. Claude Code asks you to approve the project MCP server on first use.
- `visual-reviewer` modes: `check` (vs design system), `baseline` (before upgrade/migrate), `parity` (after).
- Keep `agent-state/screens.md` to 5-10 screens; mark key ones. `agent-state/screenshots/` is git-ignored; remove that line if you want baselines committed.
- Optional: pin `@playwright/mcp` to a specific version instead of `@latest`.

## HTML prototype (optional) + handoffs
- Add `Prototype: <path>` to a `new-solution` prompt. Skip it and nothing changes.
- Flow: prototype-analyzer (haiku) -> prototype-map.md -> spec (conflicts listed) -> design-system from prototype -> build -> visual check vs prototype.
- Put page screenshots in `prototype/screenshots/` for more accurate visual checks.
- Handoffs: format in `agent-state/handoff-template.md`. You get a short Phase/Done/Produced/Decisions/Open questions/Next/Reply message at every approval and at the end.

Example:
/new-solution build from docs/requirements.md
Prototype: prototype/ (optional)
Stack: React 18, TS, Vite, Tailwind + shadcn

## fix-bug + prototype for add-feature
- `/fix-bug <description, steps to reproduce, expected vs actual, suspected files>`: debugger (root cause, reproduce first) -> approval only if high risk -> builder (failing test, minimal fix) -> reviewer -> visual check if UI bug.
- `/add-feature ... Prototype: <path>` (optional): prototype defines layout/content of the new feature; the existing design system still wins on styling.

## API spec (OpenAPI YAML)
- Put the spec at `api/openapi.yaml`, add `API spec: api/openapi.yaml` to your prompt.
- Skill `api-client` generates types, React Query hooks and MSW mocks with Orval. Spec endpoints call the real API (`VITE_API_BASE_URL`); only gap endpoints are mocked (`VITE_MOCK_GAPS=true`, default). When the backend adds them, move them into `openapi.yaml`.
- One-time: `npx msw init public/` (mock service worker). Re-run `npm run api:generate` whenever the YAML changes.

Example:
/new-solution build from docs/requirements.md
API spec: api/openapi.yaml
Prototype: prototype/ (optional)

## Partial API spec
- Gaps are listed in `agent-state/api-gaps.md`. At approval choose per gap: A) you add to `openapi.yaml`, B) agent drafts `api/openapi.proposed.yaml` (generated into `src/api/generated-proposed/`), C) manual MSW mock in `src/mocks/manual/`.
- Final handoff shows real / proposed / manual counts. When the backend confirms an endpoint, follow "When the backend confirms an endpoint" in the api-client skill.

## Hybrid API (real + mock)
- In `api/openapi.yaml` -> real API, real data. Missing -> mocked (proposed yaml or manual MSW). See "Hybrid mode" in the api-client skill and `.env.example`.
- Visual checks with real data can vary between runs; the visual-reviewer judges layout and states, not exact content.
